package controllers;

import java.util.List;

import models.Aluno;
import play.mvc.Controller;

public class Alunos extends Controller{

	public static void salvar(Aluno a) {
		if (a.nome != null) {
			a.nome = a.nome;
		}
		if (a.matricula != null) {
			a.matricula = a.matricula;
		}
		if (a.email != null) {
			a.email = a.email;
		}
		if (a.turma != null) {
			a.turma = a.turma;
		}
		if (a.nome.equals(a.matricula) || a.nome.equals(a.email)) {
			flash.error("O nome não pode ser igual à matrícula ou ao email.");
			 form(); 
		        return;
		}
		 Aluno existente = Aluno.find("byMatricula", a.matricula).first();
	        if (existente != null) {
	            flash.error("Já existe um aluno cadastrado com esta matrícula.");
	            form(); // Redireciona para o formulário de cadastro
	            return;
	        }
	
		a.save();
		listar();
	}
	
	public static void listar() {
		List<Aluno> listadeAlunos = Aluno.findAll();
		render(listadeAlunos);
	}
	
	public static void remover(long id) {
		Aluno aluno = Aluno.findById(id);
		aluno.delete();
		listar();
	}
	
	public static void form() {
		render();
	}
}
